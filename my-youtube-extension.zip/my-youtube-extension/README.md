# English
### Installation

1. Download the extension file from the repository.
2. Open your browser and go to the extensions page.
3. Enable developer mode (if it's not already enabled).
4. Click "Load unpacked" and select the folder where you saved the extension file.
5. The extension should appear in the list of installed extensions.

It will start working as soon as you open YouTube.
# Russian
### Установка

1. Скачайте файл расширения с репозитория.
2. Откройте браузер и перейдите на страницу расширений.
3. Включите режим разработчика (если он еще не включен).
4. Нажмите "Загрузить распакованное расширение" и выберите папку, в которую вы сохранили файл расширения.
5. Расширение должно появиться в списке установленных расширений.

Оно начнет работать сразу после открытия YouTube.
